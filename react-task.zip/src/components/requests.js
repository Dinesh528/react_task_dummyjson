const requests = {
    fetchSmartPhones: `/smartphones`,
   

}
export default requests;