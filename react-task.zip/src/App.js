
import './App.css';
import Products from './components/Products';
import ProductSort from './components/ProductSort';

function App() {
  return (
    <div >
      <Products/>
    </div>
  );
}

export default App;
